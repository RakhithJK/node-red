@node-red/editor-client
====================

Node-RED editor resources module.

This provides all of the client-side resources of the Node-RED editor application.

### Source

The main Node-RED modules are maintained as a monorepo on [GitHub](https://github.com/node-red/node-red).
