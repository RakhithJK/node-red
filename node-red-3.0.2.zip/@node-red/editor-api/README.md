@node-red/editor-api
====================

Node-RED editor api module.

This provides an Express application that can be used to serve the Node-RED
editor.


### Source

The main Node-RED modules are maintained as a monorepo on [GitHub](https://github.com/node-red/node-red).
